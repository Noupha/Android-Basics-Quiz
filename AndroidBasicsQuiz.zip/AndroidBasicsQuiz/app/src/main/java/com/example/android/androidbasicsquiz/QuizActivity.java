package com.example.android.androidbasicsquiz;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

/**
 * Created by nouf on 3/15/18.
 */

 public class QuizActivity extends AppCompatActivity {



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_quiz);

        }
        public void onRadioButtonClicked(View view) {
            // Is the button now checked?
            boolean checked = ((RadioButton) view).isChecked();

            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true1:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false1:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }



            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true2:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false2:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;

                case R.id.false22:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }



            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true3:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false3:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }


            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true4:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false4:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }


            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true5:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false5:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }

            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true6:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false6:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }


            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true7:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false7:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;

                case R.id.false77:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }


            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true8:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false8:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;

                case R.id.false88:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }

            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true9:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false9:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }

            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.true10:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Excellent!", Toast.LENGTH_LONG).show();
                    // Pirates are the best
                    break;
                case R.id.false10:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;

                case R.id.false100:
                    if (checked)
                        Toast.makeText(QuizActivity.this,
                                "Wrong Answer!", Toast.LENGTH_LONG).show();
                    // Ninjas rule
                    break;
            }
        }


    }



